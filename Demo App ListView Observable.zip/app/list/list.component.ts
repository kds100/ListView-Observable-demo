import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { Observable as RxObservable } from 'rxjs';
import { ActivatedRoute } from "@angular/router";

export class DataItem {
	constructor(public firstname: string, public lastname: string) { }
}

@Component({
	selector: "list",
	moduleId: module.id,
	templateUrl: "./list.component.html",
	styleUrls: ['./list.component.css'],
	changeDetection: ChangeDetectionStrategy.OnPush
})

export class ListComponent {
	public myItems: RxObservable<Array<DataItem>>;

	// Variables to hold the data from the form
	public firstname: string;
	public lastname: string;

	public constructor(private route: ActivatedRoute) {
		// Pull the data from the form as passed in via queryParam
		this.route.queryParams.subscribe(params => {
			this.firstname = params["firstname"];
			this.lastname = params["lastname"];
		});

		// For example only, for showing multple rows immediately without having to enter them
		let listItems = [
		{
			"firstname": "Jeff",
			"lastname": "Brink"
			},
			{
				"firstname": "Manojkumar",
				"lastname": "Murugesan"
			},
			{
				"firstname": "Keith",
				"lastname": "Streeter"
			}
		]; 

		// Declare the Items array and push any values into it
		var items = [];
		for (var i = 0; i < listItems.length; i++) {
			items.push(new DataItem(listItems[i].firstname, listItems[i].lastname));
		}

		// Push the data received from the form entry
		// ## NOTE - Should have data validation on the form, possibly here as well
		items.push(new DataItem(this.firstname, this.lastname));

		// Subscribe to the Observable array for future use
		var rxSubscibed;
		this.myItems = RxObservable.create(subscriber => {
			rxSubscibed = subscriber;
			subscriber.next(items);
			return function () {
				console.log("Unsubscribe called!!!");
			}
		});

	}
}

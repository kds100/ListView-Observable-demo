import { Component, OnInit } from "@angular/core";
import { Router, NavigationExtras } from "@angular/router";
import { TextField } from "tns-core-modules/ui/text-field/text-field";

@Component({
    selector: "Home",
    moduleId: module.id,
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    public firstname = "";
    public lastname = "";

    // Handle Text field changes
    public onTextChangeFirst(args) {
        let textField = <TextField>args.object;
        // Load firstname with data from field
        this.firstname = textField.text;
    }

    // Handle Text field changes
    public onTextChangeLast(args) {
        let textField = <TextField>args.object;
        // Load lastname with data from field
        this.lastname = textField.text;
    }
    public constructor(private router: Router) {
    }

    ngOnInit(): void {
    }

    onButtonTap() {
        // Prepare form fields for routing to the List Form
        let formEntryData: NavigationExtras = {
            queryParams: {
                "firstname": this.firstname,
                "lastname": this.lastname
            }
        };
        // Route to the List Form with data
        this.router.navigate(["list"], formEntryData);
    }
}
